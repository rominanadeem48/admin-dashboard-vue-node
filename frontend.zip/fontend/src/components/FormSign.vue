<template>
  <div class="center-container">
    <h2>Welcome</h2>
    <h3>ENTER YOUR LOGIN CREDENTIALS</h3>

    <form @submit.prevent="handleSubmit">
      <label for="first">Username:</label>
      <input
        type="text"
        id="first"
        v-model="username"
        placeholder="Enter your Username"
        required
      />
      <br /><br />

      <label for="password">Password:</label>
      <input
        type="password"
        id="password"
        v-model="password"
        placeholder="Enter your Password"
        required
      />
      <br /><br />

      <label for="itemsupplied">Item-Supply:</label>
      <input
        type="text"
        id="itemsupplied"
        v-model="itemsupplied"
        placeholder="Enter item you supplied"
        required
      />
      <br /><br />

      <div class="wrap">
        <button type="submit">Submit</button>
      </div>
    </form>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import axios from 'axios'

const username = ref('')
const password = ref('')
const itemsupplied = ref('')
const router = useRouter()

const handleSubmit = async () => {
  try {
    console.log(' Sending to backend:', {
      username: username.value,
      password: password.value,
      itemsupplied: itemsupplied.value
    })

    const response = await axios.post('http://localhost:3000/api/users', {
      username: username.value,
      password: password.value,
      itemsupplied: itemsupplied.value
    })

    console.log('✅ Backend response:', response.data)
    router.push('/home')
  } catch (error) {
    alert('Error sending data to backend')
    console.error('❌ Axios error:', error)
  }
}
</script>

<style scoped>
.center-container {
  display: flex;
  justify-content: center;
  flex-direction: column;
  align-items: center;
  height: 50vh;
  color: #000;
  background:#222831;
  border-radius: 50px;
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
  margin-top: 8%;
  margin-left: 25%;
  margin-right: 25%;
}

.wrap {
  display: flex;
  justify-content: flex-end;
}
</style>
