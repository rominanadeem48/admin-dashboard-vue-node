<template>
  <div class="dashboard-container">
    <!-- 🔐 If not authenticated -->
    <div v-if="!isAuthenticated" class="password-box">
      <h2>🔒 Enter Admin Password</h2>
      <input type="password" v-model="adminPassword" placeholder="Password" />
      <button @click="verifyPassword">Submit</button>
      <p v-if="errorMessage" class="error">{{ errorMessage }}</p>
    </div>

    <!-- ✅ If authenticated -->
    <div v-else>
      <h1>Welcome to Admin Dashboard</h1>

      <!-- Search -->
      <input v-model="searchTerm" placeholder="Search by username or item..." />

      <!-- User Table -->
      <div class="grid-table" v-if="filteredUsers.length">
        <div class="grid-header">No.</div>
        <div class="grid-header">Username</div>
        <div class="grid-header">Password</div>
        <div class="grid-header">Item Supplied</div>

        <template v-for="(user, index) in filteredUsers" :key="index">
          <div class="grid-cell">{{ index + 1 }}</div>
          <div class="grid-cell">{{ user.username }}</div>
          <div class="grid-cell">{{ user.password }}</div>
          <div class="grid-cell">{{ user.itemsupplied }}</div>
        </template>
      </div>

      <!-- Chart -->
      <canvas ref="chartCanvas" class="chart"></canvas>

      <!-- Summary Button -->
      <button @click="$router.push('/summary')">📊 View Summary</button>
    </div>
  </div>
</template>

<script setup>
import { ref,  watch, computed } from 'vue'
import axios from 'axios'
import Chart from 'chart.js/auto'

// 🛡️ Security related
const isAuthenticated = ref(false)
const adminPassword = ref('')
const errorMessage = ref('')
const correctPassword = 'admin123'

// 🧠 Verify password
const verifyPassword = () => {
  if (adminPassword.value === correctPassword) {
    isAuthenticated.value = true
    fetchUsers()
  } else {
    errorMessage.value = '❌ Incorrect password'
  }
}

// 📊 Data-related
const userData = ref([])
const searchTerm = ref('')
const chartCanvas = ref(null)
let chartInstance = null

// 🚀 Fetch users
const fetchUsers = async () => {
  try {
    const response = await axios.get('http://localhost:3000/api/users')
    userData.value = response.data
    updateChart()
  } catch (error) {
    alert('Error fetching user data')
    console.error(error)
  }
}

// 🔍 Filtered users
const filteredUsers = computed(() =>
  userData.value.filter(user =>
    user.username.toLowerCase().includes(searchTerm.value.toLowerCase()) ||
    user.itemsupplied.toLowerCase().includes(searchTerm.value.toLowerCase())
  )
)

// 📈 Chart update
const updateChart = () => {
  const itemCounts = {}
  userData.value.forEach(user => {
    const item = user.itemsupplied
    itemCounts[item] = (itemCounts[item] || 0) + 1
  })

  const labels = Object.keys(itemCounts)
  const values = Object.values(itemCounts)

  if (chartInstance) {
    chartInstance.destroy()
  }

  chartInstance = new Chart(chartCanvas.value, {
    type: 'bar',
    data: {
      labels,
      datasets: [
        {
          label: 'Items Supplied Count',
          data: values,
          backgroundColor: 'rgba(75, 192, 192, 0.6)',
          borderWidth: 1,
        },
      ],
    },
    options: {
      responsive: true,
      scales: {
        y: { beginAtZero: true },
      },
    },
  })
}

watch(userData, updateChart)
</script>

<style scoped>
.dashboard-container {
  padding: 20px;
}
.password-box {
  max-width: 300px;
  margin: auto;
  padding: 20px;
  background: #f4f4f4;
  border-radius: 8px;
  text-align: center;
}
input {
  padding: 10px;
  margin: 10px 0;
  width: 100%;
}
.error {
  color: red;
  font-size: 14px;
}
.grid-table {
  display: grid;
  grid-template-columns: 50px 1fr 1fr 1fr;
  margin-top: 20px;
}
.grid-header,
.grid-cell {
  padding: 10px;
  border-bottom: 1px solid #ddd;
}
</style>
