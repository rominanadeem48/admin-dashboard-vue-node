<template>
  <div class="summary-container">
    <h2> Summary Page</h2>

    <div class="card">
      <p><strong>Total Users:</strong> {{ totalUsers }}</p>
      <p><strong>Total Items Supplied:</strong> {{ totalItems }}</p>
      <p><strong>Most Supplied Item:</strong> {{ mostSuppliedItem }}</p>
      <p><strong>Least Supplied Item:</strong> {{ leastSuppliedItem }}</p>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import axios from 'axios'

// 🔹 reactive variable for user data
const users = ref([])

// 🔹 page load par data fetch
onMounted(async () => {
  const response = await axios.get('http://localhost:3000/api/users')
  users.value = response.data
})

// 🔹 total users count
const totalUsers = computed(() => users.value.length)

// 🔹 total items count
const totalItems = computed(() => {
  return users.value.filter(u => u.itemsupplied).length
})

// 🔹 sab items ka count nikalna
const itemCountMap = computed(() => {
  const map = {}
  users.value.forEach(user => {
    const item = user.itemsupplied?.toLowerCase()
    if (item) {
      map[item] = (map[item] || 0) + 1
    }
  })
  return map
})

// 🔹 most supplied item
const mostSuppliedItem = computed(() => {
  const entries = Object.entries(itemCountMap.value)
  if (entries.length === 0) return 'N/A'
  return entries.reduce((a, b) => (a[1] > b[1] ? a : b))[0]
})

// 🔹 least supplied item
const leastSuppliedItem = computed(() => {
  const entries = Object.entries(itemCountMap.value)
  if (entries.length === 0) return 'N/A'
  return entries.reduce((a, b) => (a[1] < b[1] ? a : b))[0]
})
</script>

<style scoped>
.summary-container {
  padding: 20px;
  text-align: center;
}

.card {
  background: #f8f8f8;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  display: inline-block;
}
</style>
