<template>
 <nav class="navbar">
  <div class="nav-left">Inventory Supplier</div>
  <ul class="nav-list">
            
            <li><a href="#home">Home</a></li>
            <li><a href="#about">About Us</a></li>
            <li><a href="#services">Services</a></li>
            <li><a href="#contact">Contact</a></li>
        </ul>
 </nav>
</template>

<script>
export default {
 
}
</script>

<style scoped>
.navbar {
 display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 2rem 1rem;
  width: 100%;
  margin: 0;
 background:  #222831;
  position: static;
}
.nav-list{
  list-style: none;
  font-size: 1.3rem;
  display: flex;
  gap: 2.5rem;
  padding: 0;
  margin: 0;
}
.nav-left{
  font-weight: bold;
  font-size:2rem;
  justify-content:flex-start;
  color:#000;
  
}
.nav-list li a{
color: #000;
}



</style>
