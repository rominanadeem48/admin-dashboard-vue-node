import { createWebHistory, createRouter } from 'vue-router'
import SignIn from '@/components/FormSign.vue'
import HomePage from './components/HelloPage.vue'
import SummaryPage from './components/SummaryPage.vue' // ✅ fixed path

const routes = [
  { path: '/', component: SignIn },
  { path: '/home', component: HomePage },
  { path: '/summary', component: SummaryPage }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router
