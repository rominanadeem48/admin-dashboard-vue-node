<template>
<hello-world-vue/>

<router-view/>

</template>

<script>
import HelloWorldVue from './components/HelloWorld.vue'


export default {
components:{
  HelloWorldVue
}
}
</script>

<style>
body, html {
  margin: 0;
  padding: 0;
background: #393E46;
height: 100vh;
}
</style>
